package Modal;

public class Photo {


    String phototgrapherName;
    String path;


    public String getPhototgrapherName() {
        return phototgrapherName;
    }

    public void setPhototgrapherName(String phototgrapherName) {
        this.phototgrapherName = phototgrapherName;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }



}
