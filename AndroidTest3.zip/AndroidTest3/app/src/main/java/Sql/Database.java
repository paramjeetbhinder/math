package Sql;

import android.content.ContentValues; import android.content.Context; import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase; import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Picture;
import android.support.annotation.NonNull;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import Modal.Photo;


public class Database extends SQLiteOpenHelper

{

    public Database(Context context) {


        super(context, "C000000_PhotoBook", null, 2);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        String sql =
                "CREATE TABLE Pictures" +
                        "(id	INTEGER PRIMARY KEY," +
                        "photographerName	TEXT," +
                        "photoPath TEXT)";
        db.execSQL(sql);

    }

    /*

    001: If we are changing the database we must change the previous code, we will not DROP ...
    because we don't want to lose data, we will change the table, it means "ALTER".

    002: We will remove the instruction onCreate(db), as it is not make sense anymore.

    003: We will add the checking	"DB version" to know which version we are now.

    004: Remember to go to the constructor of the class to change the DB version ...
    in our case we will change to version 2.

    */


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        String sql = "Drop table Pictures";
        db.execSQL(sql);
        onCreate(db);


    }



    // >>> REMOVED !!! >>> onCreate(db);


    // 007: Change due new column
    public void dbinsert(Photo photo) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues photoData = getContentValues(photo);
        db.insert("Pictures", null, photoData);
    }

    // 008: Change due new column
    @NonNull
    private ContentValues getContentValues(Photo photo) {
        ContentValues photoData = new ContentValues();
        photoData.put("photographerName", photo.getPhototgrapherName());
        photoData.put("photoPath", photo.getPath());
        return photoData;
        }


    // 009: Change due new column
    public List<Photo> dbSearch() {

        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * From Pictures";
        Cursor c = db.rawQuery(sql, null);
        List<Photo> photosList = new ArrayList<Photo>();

        while (c.moveToNext()) {

        Photo photo = new Photo();
            photo.setPhototgrapherName(c.getString(c.getColumnIndex("photographerName")));
            photo.setPath(c.getString(c.getColumnIndex("photoPath")));



            photosList.add(photo);
        }

        c.close();

        return photosList;
        }


        }

