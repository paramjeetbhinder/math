package com.example.project.androidtest2;

import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.ShareCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatTextView;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;


import java.io.File;

import Sql.Database;

public class DisplayGallery extends AppCompatActivity implements View.OnClickListener {

    public Button showPhotographerName;
    private GridView gridview;

    private Database db;
    public static String fullImagePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_gallery);
        db = new Database(this);
        gridview = (GridView) findViewById(R.id.gridview);
        gridview.setAdapter(new Adapter(this, db, "hide"));
        showPhotographerName = (Button) findViewById(R.id.showPhotographerName);
        showPhotographerName.setOnClickListener(this);
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {


                String name = ((AppCompatTextView)(((LinearLayout)v).getChildAt(1))).getText().toString();

                String[] paths = fullImagePath.split("/");
                paths[paths.length-1] = name;
                fullImagePath = TextUtils.join("/", paths);

                File filePhoto = new File(fullImagePath);
                Uri uriToImage = FileProvider.getUriForFile(DisplayGallery.this, BuildConfig.APPLICATION_ID + ".provider", filePhoto);
                Intent shareIntent = ShareCompat.IntentBuilder.from(DisplayGallery.this)
                        .setStream(uriToImage)
                        .getIntent();



                shareIntent.putExtra(android.content.Intent.EXTRA_TEXT, "The photo section was fantastic, please look " + name + " they are incredible");
                shareIntent.setData(uriToImage);

                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(shareIntent);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.showPhotographerName:
                gridview.setAdapter(new Adapter(this, db, "show"));

        }
    }
}
