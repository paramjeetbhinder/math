package com.example.project.androidtest2;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import Modal.Photo;
import Sql.Database;

class Adapter extends BaseAdapter {
    private Context mContext;
    private Database db;
    private List<Photo> photos;
    private String Visibility;
    public Adapter(Context c, Database db, String Visibility)
    {
        photos = db.dbSearch();
        mContext = c;
        this.Visibility = Visibility;
        db.close();


    }

    @Override
    public int getCount() {
        return photos.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View grid;
        LayoutInflater inflater = (LayoutInflater) mContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null) {

            grid = new View(mContext);
            grid = inflater.inflate(R.layout.grid_lay, null);
            TextView textView = (TextView) grid.findViewById(R.id.grid_text_view);
            TextView photographerTextView = (TextView) grid.findViewById(R.id.photographer_name_view);

            ImageView imageView = (ImageView)grid.findViewById(R.id.grid_image_view);

            imageView.setScaleType(ImageView.ScaleType.CENTER);
            imageView.setPadding(0, 0, 0, 1);
            Bitmap bitmap = BitmapFactory.decodeFile(photos.get(position).getPath());
            Bitmap lowdefBitmap = Bitmap.createScaledBitmap(bitmap, 400, 400, true);
            imageView.setImageBitmap(lowdefBitmap);


            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            imageView.setTag(photos.get(position).getPath());


            DisplayGallery.fullImagePath = imageView.getTag().toString();
            String[] name = imageView.getTag().toString().split("/");
            textView.setText(name[name.length-1]);
            if(Visibility == "show")
            {
                photographerTextView.setText(photos.get(position).getPhototgrapherName());
            }
            else{
                photographerTextView.setText("") ;
            }
            grid.setPadding(7, 7, 7, 7);
        } else {
            grid = (View) convertView;
        }



        return grid;
    }


}

