package com.example.project.androidtest2;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;

import Modal.Photo;
import Sql.Database;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    private ImageView imageView;
    private String dirPhoto;
    private static final int CAMERA_CODE = 990;
    Button clickPictureButton;
    Button savePictureButton;
    private Photo photo;
    private EditText editTextPhotographerName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        clickPictureButton = (Button) findViewById(R.id.clickPictureButton);
        imageView = (ImageView) findViewById(R.id.imageView);
        savePictureButton =  (Button) findViewById(R.id.savePictureButton);
        savePictureButton.setOnClickListener(this);
        clickPictureButton.setOnClickListener(this);
        editTextPhotographerName = (EditText) findViewById(R.id.editTextphotographerName);
        photo = new Photo();
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.savePictureButton:


                if(imageView.getDrawable() == null || editTextPhotographerName.getText().toString().isEmpty()) {
                    if (imageView.getDrawable() == null) {
                        Toast.makeText(this, "Please select Image", Toast.LENGTH_SHORT).show();

                    }
                    if (editTextPhotographerName.getText().toString().isEmpty()) {
                        editTextPhotographerName.setError("Enter Photographer name");
                    }
                }
                else{
                    editTextPhotographerName.setError(null);
                    photo.setPhototgrapherName(editTextPhotographerName.getText().toString());
                    photo.setPath((String) imageView.getTag());
                    Database db = new Database(this);
                    db.dbinsert(photo);
                    db.close();
                    Toast.makeText(this, "Photo Saved", Toast.LENGTH_SHORT).show();
                    Intent intentDisplayPics = new Intent(this, DisplayGallery.class);
                    startActivity(intentDisplayPics);
                }

                break;

            case R.id.clickPictureButton:
                Intent intentCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                dirPhoto = getExternalFilesDir(null) + "/" +System.currentTimeMillis() + ".jpg";
                File filePhoto = new File(dirPhoto);

                intentCamera.putExtra(MediaStore.EXTRA_OUTPUT, FileProvider.getUriForFile(MainActivity.this,
                        BuildConfig.APPLICATION_ID + ".provider",
                        filePhoto));
                startActivityForResult(intentCamera, CAMERA_CODE);
                break;

        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == Activity.RESULT_OK) {
                if(requestCode == CAMERA_CODE) {
                    if(dirPhoto != null)
                    {
                        Bitmap bitmap = BitmapFactory.decodeFile(dirPhoto);
                        Bitmap lowdefBitmap = Bitmap.createScaledBitmap(bitmap, 310, 310, true);
                        imageView.setImageBitmap(lowdefBitmap);
                        imageView.setScaleType(ImageView.ScaleType.FIT_XY);
                        imageView.setTag(dirPhoto);

                    }
                }
        }

    }
}
