package Database;

import android.content.ContentValues; import android.content.Context; import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase; import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

import Modal.Photo;


public class PhotoHelper extends SQLiteOpenHelper

{

    public PhotoHelper(Context context) {


        super(context, "C0000_PhotoBook", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        String sql =
                "CREATE TABLE Photos" +
                        "(id	INTEGER PRIMARY KEY," +
                        "photographer	TEXT," +
                        "path TEXT)";
        db.execSQL(sql);

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        String sql = "Drop table Photos";
        db.execSQL(sql);
        onCreate(db);


    }




    public void dbinsert(Photo photo) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues photoData = getContentValues(photo);
        db.insert("Photos", null, photoData);
    }


    @NonNull
    private ContentValues getContentValues(Photo photo) {
        ContentValues photoData = new ContentValues();
        photoData.put("photographer", photo.getPhototgrapherName());
        photoData.put("path", photo.getPath());
        return photoData;
        }


    // 009: Change due new column
    public List<Photo> dbSearch() {

        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * From Photos";
        Cursor c = db.rawQuery(sql, null);
        List<Photo> photosList = new ArrayList<Photo>();

        while (c.moveToNext()) {

        Photo photo = new Photo();
            photo.setPhototgrapherName(c.getString(c.getColumnIndex("photographer")));
            photo.setPath(c.getString(c.getColumnIndex("path")));



            photosList.add(photo);
        }

        c.close();

        return photosList;
        }


        }

