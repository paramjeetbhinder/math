package com.example.project.androidtest2;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.v4.app.ShareCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatTextView;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;


import java.io.File;

import Database.PhotoHelper;

public class DisplayPictures extends AppCompatActivity implements View.OnClickListener {

    public ImageButton showPhotographer;
    private PhotoHelper databaseHelper;
    private GridView gridview;
    public static String showPhotographerName;


    public static String imagePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pictures);
        getSupportActionBar().setTitle("Photograph App");
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.BLACK));
        databaseHelper = new PhotoHelper(this);
        gridview = (GridView) findViewById(R.id.customGridview);
        showPhotographerName = "hide";
        gridview.setAdapter(new CustomAdapter(this, databaseHelper));
        showPhotographer = (ImageButton) findViewById(R.id.showPhotographer);
        showPhotographer.setOnClickListener(this);
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {


                String picName = ((AppCompatTextView)(((LinearLayout)v).getChildAt(1))).getText().toString();
                String imagePath = ((ImageView)(((LinearLayout)v).getChildAt(0))).getTag().toString();

                File filePicture = new File(imagePath);
                Uri uriToImage = FileProvider.getUriForFile(DisplayPictures.this, BuildConfig.APPLICATION_ID + ".provider", filePicture);
                Intent shareIntent = ShareCompat.IntentBuilder.from(DisplayPictures.this)
                        .setStream(uriToImage)
                        .getIntent();



                shareIntent.putExtra(android.content.Intent.EXTRA_TEXT, "The photo section was fantastic, please look " + picName + " they are incredible");
                shareIntent.setData(uriToImage);

                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(shareIntent);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.showPhotographer:
                showPhotographerName = "show";
                gridview.setAdapter(new CustomAdapter(this, databaseHelper));

        }
    }
}
