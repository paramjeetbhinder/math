package com.example.project.androidtest2;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import Modal.Photo;
import Database.PhotoHelper;

class CustomAdapter extends BaseAdapter {

    private List<Photo> mPhoto;
    private Context context;
    private PhotoHelper photoHelper;


    public CustomAdapter(Context c, PhotoHelper photoHelper)
    {
        mPhoto = photoHelper.dbSearch();
        context = c;
        photoHelper.close();


    }



    // create a new ImageView for each item referenced by the CustomAdapter
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View gridView;
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null) {

            gridView = new View(context);
            gridView = inflater.inflate(R.layout.grid_layout, null);
            TextView textView = (TextView) gridView.findViewById(R.id.grid_text_view);
            TextView photographerText = (TextView) gridView.findViewById(R.id.photographer_name_view);

            ImageView imageView = (ImageView)gridView.findViewById(R.id.grid_image_view);

            imageView.setScaleType(ImageView.ScaleType.CENTER);
            imageView.setPadding(0, 0, 0, 1);
            Bitmap bitmap = BitmapFactory.decodeFile(mPhoto.get(position).getPath());
            Bitmap lowdefBitmap = Bitmap.createScaledBitmap(bitmap, 410, 410, true);
            imageView.setImageBitmap(lowdefBitmap);


            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            imageView.setTag(mPhoto.get(position).getPath());


            DisplayPictures.imagePath = imageView.getTag().toString();
            String[] name = imageView.getTag().toString().split("/");
            textView.setText(name[name.length-1]);
            if(DisplayPictures.showPhotographerName == "show")
            {
                photographerText.setText(mPhoto.get(position).getPhototgrapherName());
            }
            else{
                photographerText.setText("") ;
            }
            gridView.setPadding(7, 7, 7, 7);
        } else {
            gridView = (View) convertView;
        }



        return gridView;
    }
    @Override
    public int getCount() {
        return mPhoto.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }


}

