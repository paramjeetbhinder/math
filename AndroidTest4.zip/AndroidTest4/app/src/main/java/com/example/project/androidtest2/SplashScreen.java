package com.example.project.androidtest2;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

public class SplashScreen extends AppCompatActivity {
    ProgressBar progressBar;
    TextView splashTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setTitle("Photograph App");
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.BLACK));
        setContentView(R.layout.activity_splash);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        splashTextView = (TextView) findViewById(R.id.splashText);

        new Thread(new Runnable() {
            public void run() {
                loading();
                startActivity();
                finish();
            }
        }).start();
    }

    private void loading() {
        for (int i=0; i<=100; i+=2) {
            try {
                Thread.sleep(70);
                progressBar.setProgress(i);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void startActivity() {
        Intent intent = new Intent(SplashScreen.this, MainActivity.class);
        startActivity(intent);
    }
}
