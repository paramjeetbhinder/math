package com.example.project.androidtest2;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;

import Modal.Photo;
import Database.PhotoHelper;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    private ImageView imageView;
    private String photoLocation;
    private static final int CAMERA_CODE = 990;
    ImageButton clickPicture;
    Button savePicture;
    private Photo picture;
    private EditText editPhotographerName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Photograph App");
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.BLACK));
        clickPicture = (ImageButton) findViewById(R.id.clickPicture);
        imageView = (ImageView) findViewById(R.id.imageView);
        savePicture =  (Button) findViewById(R.id.savePicBtn);
        savePicture.setOnClickListener(this);
        clickPicture.setOnClickListener(this);
        editPhotographerName = (EditText) findViewById(R.id.editphotographerName);
        picture = new Photo();
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.savePicBtn:


                if(imageView.getDrawable() == null || editPhotographerName.getText().toString().isEmpty()) {
                    if (imageView.getDrawable() == null) {
                        Toast.makeText(this, "Please select Image", Toast.LENGTH_SHORT).show();

                    }
                    if (editPhotographerName.getText().toString().isEmpty()) {
                        editPhotographerName.setError("Photographer name is empty");
                    }
                }
                else{
                    editPhotographerName.setError(null);
                    picture.setPhototgrapherName(editPhotographerName.getText().toString());
                    picture.setPath((String) imageView.getTag());
                    PhotoHelper database = new PhotoHelper(this);
                    database.dbinsert(picture);
                    database.close();
                    Toast.makeText(this, "Pic Saved", Toast.LENGTH_SHORT).show();
                    Intent intentDisplayPics = new Intent(this, DisplayPictures.class);
                    startActivity(intentDisplayPics);
                }

                break;

            case R.id.clickPicture:
                Intent intentCameraOpen = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                photoLocation = getExternalFilesDir(null) + "/" +System.currentTimeMillis() + ".jpg";
                File filePicture = new File(photoLocation);

                intentCameraOpen.putExtra(MediaStore.EXTRA_OUTPUT, FileProvider.getUriForFile(MainActivity.this,
                        BuildConfig.APPLICATION_ID + ".provider",
                        filePicture));
                startActivityForResult(intentCameraOpen, CAMERA_CODE);
                break;

        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == Activity.RESULT_OK) {
                if(requestCode == CAMERA_CODE) {
                    if(photoLocation != null)
                    {
                        Bitmap bitmap = BitmapFactory.decodeFile(photoLocation);
                        Bitmap lowdefBitmap = Bitmap.createScaledBitmap(bitmap, 310, 310, true);
                        imageView.setImageBitmap(lowdefBitmap);
                        imageView.setScaleType(ImageView.ScaleType.FIT_XY);
                        imageView.setTag(photoLocation);

                    }
                }
        }

    }
}
